using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazorPagesAdvanced.Models;
using System.Collections.Generic;
using System.Linq;

namespace RazorPagesAdvanced.Pages.Products
{
    public class DetailsModel : PageModel
    {
        public Product Product { get; set; }

        public IActionResult OnGet(int id)
        {
            var categories = new List<Category>
            {
                new Category { CategoryID = 1, CategoryName = "Electronics" },
                new Category { CategoryID = 2, CategoryName = "Books" }
            };

            var allProducts = new List<Product>
            {
                new Product { ProductID = 1, Name = "Laptop", Description = "A high-performance laptop.", Price = 1200.00m, StockQuantity = 10, CategoryID = 1, Category = categories[0] },
                new Product { ProductID = 2, Name = "Mouse", Description = "A wireless optical mouse.", Price = 25.50m, StockQuantity = 50, CategoryID = 1, Category = categories[0] },
                new Product { ProductID = 3, Name = "Book", Description = "A thrilling mystery novel.", Price = 15.99m, StockQuantity = 100, CategoryID = 2, Category = categories[1] }
            };

            Product = allProducts.FirstOrDefault(p => p.ProductID == id);

            if (Product == null)
            {
                return NotFound();
            }

            return Page();
        }
    }
}