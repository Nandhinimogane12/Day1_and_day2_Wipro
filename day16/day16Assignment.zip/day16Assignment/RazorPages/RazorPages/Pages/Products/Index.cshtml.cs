using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using RazorPagesAdvanced.Models;
using System.Collections.Generic;
using System.Linq;

namespace RazorPagesAdvanced.Pages.Products
{
    public class IndexModel : PageModel
    {
        public List<Product> Products { get; set; }
        public List<SelectListItem> CategoryList { get; set; }

        [BindProperty(SupportsGet = true)]
        public string SearchTerm { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? SelectedCategoryId { get; set; }

        public void OnGet()
        {
            var categories = new List<Category>
            {
                new Category { CategoryID = 1, CategoryName = "Electronics" },
                new Category { CategoryID = 2, CategoryName = "Books" }
            };

            var allProducts = new List<Product>
            {
                new Product { ProductID = 1, Name = "Laptop", Description = "A high-performance laptop.", Price = 1200.00m, StockQuantity = 10, CategoryID = 1, Category = categories[0] },
                new Product { ProductID = 2, Name = "Mouse", Description = "A wireless optical mouse.", Price = 25.50m, StockQuantity = 50, CategoryID = 1, Category = categories[0] },
                new Product { ProductID = 3, Name = "Book", Description = "A thrilling mystery novel.", Price = 15.99m, StockQuantity = 100, CategoryID = 2, Category = categories[1] }
            };

            CategoryList = categories.Select(c => new SelectListItem { Value = c.CategoryID.ToString(), Text = c.CategoryName }).ToList();

            Products = allProducts;

            if (!string.IsNullOrEmpty(SearchTerm))
            {
                Products = Products.Where(p => p.Name.Contains(SearchTerm, System.StringComparison.OrdinalIgnoreCase)).ToList();
            }

            if (SelectedCategoryId.HasValue)
            {
                Products = Products.Where(p => p.CategoryID == SelectedCategoryId.Value).ToList();
            }
        }
    }
}